#include<iostream>
#include<fstream>
#include<ctime>
#include<string.h>
#include<stdio.h>

using namespace std;
int obs=5,s=0;
    int search_stock(int match){
               stock C;
               int i,id,g=0;
               cout<<"enter book id:";
               cin>>id;
               {ifstream f;
               f.open("stock.txt",ios::in);
               for(i=1;i<=obs;i++){
                f.read((char*)&C,sizeof(C));
                if(C.book_id==id){
                    cout<<"Match found"<<endl;
                    // match=2;
                    g=match;
                    f.close();
                    return(match);
                    // break;
                }
               }
               }
            //    if(g==match){
            //        return(match);
            //    }
               if(g==0){
                   return 20;
               }
    }


    void cfile_to_og(){
    stock C;
    int i;
    {ifstream f5;
    f5.open("obs.txt",ios::in);
    f5>>obs;
    f5.close();
    }
    {ifstream f2;
     ofstream f3;
     f2.open("cstock.txt",ios::in);
     f3.open("stock.txt",ios::out);
     for(i=1;i<=obs;i++){
         f2.read((char*)&C,sizeof(C));
         f3.write((char*)&C,sizeof(C));
     }
     f2.close();
     f3.close();
    }
    }
class stock{
    public:
    int book_id;
    char author[20];
    int isbn;
    int pages;
    int year;
    int price;
    int no_of_copies;

    void input(){
        cout<<"enter book_id:";
        cin>>book_id;
        cout<<"enter author name:";
        fflush(stdin);
        gets(author);
        cout<<"enter isbn :";
        cin>>isbn;
        cout<<"enter no_of pages:";
        cin>>pages;
        cout<<"enter pub. year:";
        cin>>year;
        cout<<"enter price";
        cin>>price;
        cout<<"no. of copies";
        cin>>no_of_copies;
    }
    void output(){
        cout<<"Book_id:"<<book_id<<" | "<<"Author Name:"<<author<<" | "<<"ISBN no. :"<<isbn<<" | "<<"no. of pages:"<<pages<<" | "<<"Year of Publicition:"<<year<<" | "<<"price:"<<price<<" | "<<"No. of copies"<<no_of_copies<<endl;
    }
};

class admin{
    private:
    // stock N;
    // stock C;
    // student S;
    char usrname_og[20];
    char password_og[20];
    int i,id;
    public:
    admin(){
        strcpy(usrname_og,"nurav07");
        strcpy(password_og,"70varun");
        i=1;
        id=0;
    }
    ~admin(){
    }
    int action_on_stock(){
    int result=0;
    {ifstream f5;
    f5.open("obs.txt",ios::in);
    f5>>obs;
    f5.close();
    }
    a:
    cout<<"enter 1 to add stock"<<endl;
    cout<<"enter 2 to delete a book from stock"<<endl;
    cout<<"enter 3 to edit book details"<<endl;
    cin>>result;
    int match=0;
    int j;
    stock N,C; 
    switch(result){
        case 1:cout<<"Enter Book Credentials"<<endl;
               N.input();
               {ifstream f;
               f.open("stock.txt",ios::in);
               for(i=1;i<=obs;i++){
                   f.read((char*)&C,sizeof(C));
                   if(N.book_id==C.book_id && N.isbn==C.isbn && N.pages==C.pages && N.year==C.year && N.price==C.price){
                       f.close();
                       match=1;
                       break;
                   }
                }
                if(match==1){
                {ifstream f2;
                ofstream f3;
                f2.open("stock.txt",ios::in);
                f3.open("cstock.txt",ios::out);
                for(j=1;j<=obs;j++){
                f2.read((char*)&C,sizeof(C));
                if(j==i){
                    C.no_of_copies++;
                }          
                f3.write((char*)&C,sizeof(C));
                }
                f2.close();
                f3.close();}
                cfile_to_og();
                }
                else{
                    f.close();
                    {ofstream f2;
                    f2.open("stock.txt",ios::app);
                    f2.write((char*)&N,sizeof(N));
                    obs++;
                    f2.close();
                    }
                }
                break;
                }


        case 2:
            //    cout<<"ENTER BOOK ID :";
            //    cin>>id;
            //    {ifstream f;
            //    f.open("stock.txt",ios::in);-------------------------------------------------------------->1
            //    for(i=1;i<=obs;i++){
            //     f.read((char*)&C,sizeof(C));
            //     if(C.book_id==id){
            //         cout<<"Match found"<<endl;
            //         match=2;
            //         f.close();
            //         break;
            //     }
            //    }
                match=search_stock(2);
               if(match==2){
                {ifstream f2;
                ofstream f3;
                f2.open("stock.txt",ios::in);
                f3.open("cstock.txt",ios::out);
                for(j=1;j<=obs;j++){
                f2.read((char*)&C,sizeof(C));
                if(j==i){
                    obs--;
                    continue;
                }
                f3.write((char*)&C,sizeof(C));
                }
                f2.close();
                f3.close();
                cfile_to_og();
                }

               }
               else{
                   cout<<"No record found for this id"<<endl;
                //    f.close();
               }
            //    }
               break;

        case 3:
            //    cout<<"ENTER BOOK ID :";
            //    cin>>id;
            //    {ifstream f;
            //    f.open("stock.txt",ios::in);
            //    for(i=1;i<=obs;i++){
            //     f.read((char*)&C,sizeof(C));
            //     if(C.book_id==id){
            //         cout<<"Match found"<<endl;
            //         match=3;
            //         f.close();
            //         break;
            //     }
            //    }
                match=search_stock(3);
               if(match==3){
                {ifstream f2;
                ofstream f3;
                f2.open("stock.txt",ios::in);
                f3.open("cstock.txt",ios::out);
                for(j=1;j<=obs;j++){
                f2.read((char*)&C,sizeof(C));
                if(j==i){
                    cout<<"OG DETAILS ARE :"<<endl;
                    C.output();
                    cout<<"enter new details"<<endl;
                    C.input();
                }
                f3.write((char*)&C,sizeof(C));
                }
                f2.close();
                f3.close();
                cfile_to_og();
               }
               }
               else{
                   cout<<"No record found for this id"<<endl;
                //    f.close();
               }
            //    }
               break;
        
        default: cout<<"WRONG INPUT"<<endl;
                 goto a;
    }
    ofstream f5;
    f5.open("obs.txt",ios::out);
    f5<<obs;
    f5.close();
    cout<<"enter 0 to return to the main menu"<<endl;
    cin>>result;
    if(result==0){
        return 0;
    }
    else{
        return (-1);
    }
    }
    void login_check(){
    char usrname[20];
    char password[20];
    int revert=0;

    cout<<"enter username :";
    fflush(stdin);
    gets(usrname);
    cout<<"enter password :";
    gets(password);
    if((strcmp(password,password_og)==0) && (strcmp(usrname,usrname_og)==0)){
    cout<<"LOGIN SUCCCESSFUL"<<endl;
    m:
    cout<<"Enter 1 for stock related Actions"<<endl;
    cout<<"Enter 2 for student related Actions"<<endl;
    cin>>revert;
    switch(revert){
        case 1:revert=action_on_stock();
               if(revert==0){
                   goto m;
               }
               else{
                   cout<<"LOGGED OUT"<<endl;
                   exit(0);
               }
               break;
        // case 2:revert=action_on_student();
        if(revert==1){
            goto m;
        }
        else{
            cout<<"LOGGED OUT"<<endl;
            exit(0);
        }
        break;

        default:cout<<"Wrong Credentiials"<<endl;
    }
    }
    }

};
int main(){
    {ifstream f7;
          f7.open("s.txt",ios::in);
          f7>>s; 
          f7.close();
    } 
    int revert=-1;
    s:
    cout<<"Enter 1 for Admin login"<<endl;
    cout<<"Enter 0 for student login & signup"<<endl;
    cin>>revert;
    if(revert==1){
        admin A;
        A.login_check();
    }
